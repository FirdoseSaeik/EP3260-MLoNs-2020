# Import libraries
from keras.datasets import mnist
import matplotlib.pyplot as plt
import numpy as np
from tqdm import tqdm
from pylab import rcParams

# Preparing the dataset
image_size = 784
num_iter = 1500
num_classes = 10

(x_train, y_train), (x_test, y_test) = mnist.load_data()
x_train_drawing = x_train
x_train = x_train.reshape(x_train.shape[0], image_size) 
x_test = x_test.reshape(x_test.shape[0], image_size)
X_data = x_train/255.0
x_test = x_test/255.0
y = y_train
acc_list = []


def svm_loss_vectorized(X, Y, W, reg):
    delta = 1.0
    num_train = X.shape[0]

    patch_X = X
    patch_Y = Y

    patch_result = patch_X.dot(W)
    sample_label_value = patch_result[[range(patch_result.shape[0])], patch_Y]
    loss_array = np.maximum(0, patch_result - sample_label_value.T + delta)
    loss_array[[range(patch_result.shape[0])], patch_Y] = 0

    loss = np.sum(loss_array) / num_train + 0.5 * reg * np.sum(W * W)
    loss_array[loss_array > 0] = 1
    loss_array[[range(patch_result.shape[0])], patch_Y] = -np.sum(loss_array, 1)

    dW = np.dot(np.transpose(patch_X), loss_array)
    dW /= num_train
    dW += reg * W

    return loss, dW


# Split dataset to num_worker workers
def split_workers(X_data, y_data, num_worker):
    data_X_list = []
    data_y_list = []
    num_data = len(y_data)
    num_per_data = num_data // num_worker
    for i_th in range(num_worker):
        j = num_per_data * (i_th + 1)
        i = i_th*num_per_data
        x_data_worker = X_data[i:j]
        y_data_worker = y_data[i:j]
        data_X_list.append(x_data_worker)
        data_y_list.append(y_data_worker)

    return data_X_list, data_y_list


def predict(X, W):
    y_pred = np.zeros(X.shape[1])
    y_pred = np.argmax(X.dot(W), axis=1)

    return y_pred


def cal_acc(y_p, y):
    return sum(y_p == y)/len(y)


def train(X_data, y, num_worker_1, num_worker_2, num_iter, var, pLevel, lamda, alpha, lr_fade=1):
    num_worker = num_worker_1+num_worker_2
    data_X_list, data_y_list = split_workers(X_data, y, num_worker)
    # train
    weight = np.random.rand(X_data.shape[1], num_classes)
    weight_1 = np.random.rand(X_data.shape[1], num_classes)
    weight_2 = np.random.rand(X_data.shape[1], num_classes)

    k = 1
    weights = []
    total_loss_list = []

    for i_iter in tqdm(range(num_iter)):
        gradient_list_1 = []
        gradient_list_2 = []

        for j_worker in range(num_worker_1):
            # call data_j from worker j
            X_ = data_X_list[j_worker]
            y_ = data_y_list[j_worker]
            # get grad from worker j
            _, grad = svm_loss_vectorized(X_, y_, weight, lamda)
            # add noise
            noise = np.random.normal(0, var)
            prob = np.random.uniform(0, 1)
            grad = grad + noise * (prob <= pLevel)
            gradient_list_1.append(grad)
        alpha *= lr_fade
        weight_1 -= alpha * 1./num_worker_1*sum(gradient_list_1)

        for j_worker in range(num_worker_1, num_worker_1+num_worker_2):
            # call data_j from worker j
            X_ = data_X_list[j_worker]
            y_ = data_y_list[j_worker]
            # get grad from worker j
            _, grad = svm_loss_vectorized(X_, y_, weight, lamda)
            # add noise
            noise = np.random.normal(0, var)
            prob = np.random.uniform(0, 1)
            grad = grad + noise * (prob <= pLevel)
            gradient_list_2.append(grad)
        alpha *= lr_fade
        weight_2 -= alpha * 1./num_worker_2*sum(gradient_list_2)

        weight = (weight_1 + weight_2)*0.5

        if k > 1:
            if i_iter == 0:
                weights.append(np.copy(weight))
            elif i_iter < k:
                weights.append(np.copy(weight))
                weights[-1] = sum(weights)/len(weights)
            else:
                weights.append(np.copy(weight))
                weights[-1] = sum(weights[-k:])/len(weights[-k:])

            loss, _ = svm_loss_vectorized(X_data, y, weights[-1], lamda)
        else:
            loss, _ = svm_loss_vectorized(X_data, y, weight, lamda)

        total_loss_list.append(loss)

        if k > 1:
            y_pred = predict(x_test, weights[-1])
        else:
            y_pred = predict(x_test, weight)

        acc = cal_acc(y_pred, y_test)
        acc_list.append(acc)

    return total_loss_list


# Tune noise and consider ? iterations
def tuningNoise(var, pLevel):
    return train(X_data, y, num_worker_1=5, num_worker_2=5, num_iter=num_iter, var=var, pLevel=pLevel, lamda=0.03, alpha=0.03, lr_fade=1)


plt.figure(1)
Loss_var = []
acc_var = []
varList = [0, 0.1, 0.4, 0.7, 1]

for i in varList:
    acc_list = []
    Loss_var.append(tuningNoise(var=i, pLevel=0.5))
    acc_var.append(acc_list)

rcParams['figure.figsize'] = 8, 6

x_axis = np.arange(0, num_iter)
for i in tqdm(range(len(Loss_var))):
    plt.semilogy(x_axis, Loss_var[i], label='R=%.2f, P=0.5' % (varList[i]))

plt.xlabel('Num_of_iter')
plt.ylabel('Total loss')
plt.legend(loc='upper right', prop={'size': 10})
plt.savefig('2-1-new.png')

# ====
plt.figure(2)
rcParams['figure.figsize'] = 8, 6

x_axis = np.arange(0, num_iter)
for i in tqdm(range(len(Loss_var))):
    plt.semilogy(x_axis, acc_var[i], label='R=%.2f, P=0.5' % (varList[i]))

plt.xlabel('Num_of_iter')
plt.ylabel('Testing Accuracy')
plt.legend(loc='upper right', prop={'size': 10})
plt.savefig('2-1-acc.png')

# ====

plt.figure(3)
Loss_p = []
acc_p = []
pList = [0, 0.1, 0.4, 0.7, 1]
for i in pList:
    acc_list = []
    Loss_p.append(tuningNoise(var=0.5, pLevel=i))
    acc_p.append(acc_list)

rcParams['figure.figsize'] = 8, 6
x_axis = np.arange(0, num_iter)
for i in tqdm(range(len(Loss_p))):
    plt.plot(x_axis, Loss_p[i], label='R=0.5, P=%.2f' % (pList[i]))

plt.xlabel('Num_of_iter')
plt.ylabel('Total loss')
plt.legend(loc='upper right', prop={'size': 10})
plt.savefig('2-2-new.png')

# ========
plt.figure(4)
rcParams['figure.figsize'] = 8, 6

x_axis = np.arange(0, num_iter)
for i in tqdm(range(len(Loss_p))):
    plt.plot(x_axis, acc_p[i], label='R=%.2f, P=0.5' % (pList[i]))

plt.xlabel('Num_of_iter')
plt.ylabel('Testing Accuracy')
plt.legend(loc='upper right', prop={'size': 10})
plt.savefig('2-2-acc.png')
