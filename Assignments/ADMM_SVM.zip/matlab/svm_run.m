rand('seed', 3);
randn('seed', 3);

n = 2;
m = 400;
N = m/2;
M = m/2;

% positive examples
Y = [1.5+0.9*randn(1,0.6*N), 1.5+0.7*randn(1,0.4*N);
2*(randn(1,0.6*N)+1), 2*(randn(1,0.4*N)-1)];

% negative examples
X = [-1.5+0.9*randn(1,0.6*M),  -1.5+0.7*randn(1,0.4*M);
2*(randn(1,0.6*M)-1), 2*(randn(1,0.4*M)+1)];

x = [X Y];
y = [ones(1,N) -ones(1,M)];
A = [ -((ones(n,1)*y).*x)' -y'];
xdat = x';
lambda = 1.0;

% partition the examples up in the worst possible way
% (subsystems only have positive or negative examples)
p = zeros(1,m);
p(y == 1)  = sort(randi([1 10], sum(y==1),1));
p(y == -1) = sort(randi([11 20], sum(y==-1),1));

%% solve problem
[x history] = linear_svm(A, lambda, p, 1.0, 1.0);

%% Reporting

K = length(history.objval);

h = figure;
plot(1:K, history.objval, 'k', 'MarkerSize', 10, 'LineWidth', 2);
ylabel('f(x^k) + g(z^k)'); xlabel('iter (k)');

g = figure;
subplot(2,1,1);
semilogy(1:K, max(1e-8, history.r_norm), 'k', ...
    1:K, history.eps_pri, 'k--',  'LineWidth', 2);
ylabel('||r||_2');

subplot(2,1,2);
semilogy(1:K, max(1e-8, history.s_norm), 'k', ...
    1:K, history.eps_dual, 'k--', 'LineWidth', 2);
ylabel('||s||_2'); xlabel('iter (k)');
%% ploting data
%load('svm_data.mat')
%X = Data(:,1:100);
%Y = Data(:, 101:end);
%x = [W;b]
figure;
plot(X(1,:), X(2,:), 'o'); hold on;
plot(Y(1,:), Y(2,:), 'x'); hold on;
minx = min(min(X(1,:)), min(Y(1,:)));
miny = min(min(X(2,:)), min(Y(2,:)));
maxx = max(max(X(1,:)), max(Y(1,:)));
maxy = max(max(X(2,:)), max(Y(2,:)));

xx = linspace(minx, maxx);
yy = -(x(1)*xx + x(3))/x(2);
plot(xx, yy, 'k--')
xlim(1.01*[minx, maxx])
ylim(1.01*[miny, maxy])
