# -*- coding: utf-8 -*-
"""
Created on Tue Mar  3 16:49:59 2020

@author: Henke
"""

##Imports from libraries
import pandas as pd
import numpy as np
import time
import matplotlib.pyplot as plt
import ca2

## Preprocessing of data
# Load data here:
dataset = pd.read_csv('merge.dat', delimiter=' ', header=None, index_col=False)

maxval = np.max(np.max(dataset))
dataset = dataset/(maxval/100);
mean = np.mean(np.mean(dataset))
print('mean=' + str(mean))
dataset = dataset-mean
print('mean2=' + str(np.mean(np.mean(dataset))))

#scaler = MinMaxScaler(feature_range=(0, 1)) 
#rescaledDataset = scaler.fit_transform(dataset) 
#dataset = pd.DataFrame(rescaledDataset)

# Split train and test data here: (X_train, Y_train, X_test, Y_test)
[X_train, Y_train, X_test, Y_test] = ca2.split_test_train(dataset, 0.2)


## Logistic ridge regression with different optimizers
# cost function and gradient calculation

def cost(x,y,w,lambda_):
    N,D = x.shape
    XW = np.matmul(x, w)
    XWY = np.multiply(XW,y)
    expterm = np.exp(-XWY)
    sumterm = np.log(1+expterm)
    sum_ = np.sum(sumterm)
    penalty = lambda_*( np.linalg.norm(w)**2 )
    ret = sum_/N+penalty
    
    return ret

def function_gradient(X, Y, w, lambda_, j):
    N,D = X.shape
    XW = np.matmul(X, w)
    XWY = np.multiply(XW,Y)
    term = np.zeros((N,D))
    den = np.exp(XWY)+1
    for i in range(D):
        x = X[:,i]
        YX = -np.multiply(x,Y)
        term[:,i] = np.divide(YX, den)
    sum_ = np.sum(term, axis=0)
    ret = sum_/N+2*lambda_*w
    """
    if j%10==0:
        print('j=' + str(j))
        print('sum_/N=' + str(sum_/N))
        print('penalty=' + str(2*lambda_*w))
    """ 
    return ret

## Define solvers: GD, SGD, SVRG and SAG. 
# Setting the values here:

alpha = 0.05 # change the value
lambda_ = 0.01 # change the value
epsilon = 0.0000001 # change the value
batchsize = 10

def solver(x, y, w, alpha, num_iters , lambda_ , epsilon , optimizer = "GD", 
           mem=False):
    cost_vec = np.zeros(num_iters+1)
    cost_vec[0] = cost(x, y, w, lambda_)
    
    if (optimizer == "GD") :
        print("GD")
        for i in range(num_iters):
            # update the parameter w for GD here:
            g = function_gradient(x, y, w, lambda_, i)
            w = w - alpha*g
            cost_vec[i+1] = cost(x, y, w, lambda_)
            
            if (np.linalg.norm(g) <= epsilon):
                print('g=' + str(g))
                print('Detected small gradient, stopping!')
                break
             
                
    elif (optimizer == "SGD"):
        print("SGD")
        for i in range(num_iters):
            # Complete SGD here:
            random_rows = np.random.randint(0,x.shape[0],batchsize)
            batch_x = x[random_rows,:]
            batch_y = y[random_rows]
            # update the parameter w for SGD here:
            g = function_gradient(batch_x, batch_y, w, lambda_, i)
            w = w - alpha*g
            cost_vec[i+1] = cost(x, y, w, lambda_)
            
            if (np.linalg.norm(g) <= epsilon):
                print('g=' + str(g))
                print('Detected small gradient, stopping!')
                break
     
              
    elif (optimizer == "SVRG"):
        #Initialize snap vectors
        wsnap = w
        sgsnap = w
        gsnap = w
        for i in range(num_iters):
            #Batch selection
            random_rows = np.random.randint(0,x.shape[0],batchsize)
            batch_x = x[random_rows,:]
            batch_y = y[random_rows]
            #Stochastic Gradient with w
            sg = function_gradient(batch_x, batch_y, w, lambda_, i)
            #Snapshot w
            if i%10==0:
                wsnap = w
                #Stochastic Gradient with wsnap
                sgsnap = function_gradient(batch_x, batch_y, wsnap, lambda_, i)
                #Gradient with wsnap
                gsnap = function_gradient(x, y, wsnap, lambda_, i)
            #Update w
            w = w - alpha*(sg-sgsnap+gsnap)
            cost_vec[i+1] = cost(x, y, w, lambda_)
        

    """    
     
    elif (optimizer == "SAG"):
        # Complete SAG here:
            """
    return w, cost_vec

## Solving the optimization problem:

y = np.array(Y_train.iloc[0:X_train.shape[0]])
x = np.array(X_train.iloc[0:X_train.shape[0],:])
print('xshape=' + str(x.shape))
N,D = x.shape
#Add column of 1s for constant term
one_mat = np.ones((N,D+1))
one_mat[:,range(1,D+1)]=x
x = one_mat
w = np.random.rand(D+1)*0.1  # Initialization of w

# Turning Y into a binary variable
#av_Y = (np.mean(Y_train)+np.mean(Y_test))/2
#print('av_Y=' + str(av_Y))
#y = np.where(y > av_Y, 1, -1)

#-------------------- GD Solver -----------------------
"""
num_iters = 80 # change the value

cost_value_pre = cost(x, y, w, lambda_)  # Calculate the cost value

start = time.time()
(gde, cost_vec) = solver(x, y, w, alpha, num_iters, lambda_, epsilon, "GD", False) # complete the command 
end = time.time()
print("Weights of GD after convergence: \n" + str(gde))
cost_value = cost(x, y, gde, lambda_)  # Calculate the cost value
print("Cost of GD after convergence: \n" + str(cost_value))
print("Cost of GD improvement: \n" + str(cost_value_pre-cost_value))

print("Cost vector: \n" + str(cost_vec))
print("Training time for GD: " + str(end-start))


plt.plot(range(num_iters+1), cost_vec)

#-------------------- SGD Solver -----------------------
# complete here :
num_iters = 100
w = np.random.rand(D+1)*0.1  # Initialization of w

cost_value_pre = cost(x, y, w, lambda_)  # Calculate the cost value

start = time.time()
(gde, cost_vec) = solver(x, y, w, alpha, num_iters, lambda_, epsilon, "SGD", False) # complete the command 
end = time.time()
print("Weights of SGD after convergence: \n" + str(gde))
cost_value = cost(x, y, gde, lambda_)  # Calculate the cost value
print("Cost of SGD after convergence: \n" + str(cost_value))
print("Cost of SGD improvement: \n" + str(cost_value_pre-cost_value))

print("Cost vector: \n" + str(cost_vec))
print("Training time for SGD: " + str(end-start))


plt.plot(range(num_iters+1), cost_vec)
"""
#-------------------- SVRG Solver -----------------------
# complete here :
num_iters = 200 # change the value
w = np.random.rand(D+1)*0.1  # Initialization of w

cost_value_pre = cost(x, y, w, lambda_)  # Calculate the cost value

start = time.time()
(gde, cost_vec) = solver(x, y, w, alpha, num_iters, lambda_, epsilon, "SVRG", False) # complete the command 
end = time.time()
print("Weights of SVRG after convergence: \n" + str(gde))
cost_value = cost(x, y, gde, lambda_)  # Calculate the cost value
print("Cost of SVRG after convergence: \n" + str(cost_value))
print("Cost of SVRG improvement: \n" + str(cost_value_pre-cost_value))

print("Cost vector: \n" + str(cost_vec))
print("Training time for SVRG: " + str(end-start))

plt.plot(range(num_iters+1), cost_vec)

#-------------------- SAG Solver -----------------------

## Executing the iterations and plot the cost function here:
"""
ti= np.zeros((50,4))
cost_= np.zeros((50,4))
for i in range(50):
    print("......",i,".......")
    #--------------GD-------------------
    start = time.time()
    gde = solver(x, y, w, alpha, num_iters, lambda_, epsilon)
    end = time.time()

    cost_[i,0] = cost(x, y, gde, lambda_)

    ti[i,0] = end-start

    #---------------SGD------------------
    #Complete for SGD solver here :
    
    #---------------SVRG----------------
    #Complete for SVRG solver here :
    
    #---------------SAG------------------
    #Complete for SAG solver here :
    
    #------------------------------------
    
    ## Pl the results:
    

l0 = plt.plot(cost_[:,0],color="red")
# complete other plots here: 


plt.xlabel("Number of Iteration")
plt.ylabel("Cost")
plt.legend(['GD', 'SGD', 'SVRG', 'SAG'])
plt.show()

l0 = plt.plot(ti[:,0],color="red")
# complete other plots here:

plt.xlabel("Number of Iteration")
plt.ylabel("Time (sec)")
plt.legend(['GD', 'SGD', 'SVRG', 'SAG'])
plt.show()
# complete here :
"""

