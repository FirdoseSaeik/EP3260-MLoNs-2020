# -*- coding: utf-8 -*-
"""
Created on Tue Mar  3 16:49:59 2020

@author: Henke
"""

import numpy as np
import pandas as pd
import time

MIN_ID = 2
MAX_ID = 2921

def id_to_str(filename_id):
    ret = ''
    if filename_id < 10:
        ret = '000' + str(filename_id)
    elif filename_id < 100:
        ret = '00' + str(filename_id)
    elif filename_id < 1000:
        ret = '0' + str(filename_id)
    else:
        ret = str(filename_id)
    return ret
    
filename_base = 'ghg_data/ghg.gid.site'
filename_trail = '.dat'


dataset = pd.DataFrame()
start = time.time()
for filename_id in range(MIN_ID, MAX_ID+1):
    filename = filename_base+id_to_str(filename_id)+filename_trail
    file_data = pd.read_csv(filename, delimiter=' ', header=None, index_col=False)
    file_data = file_data.transpose()
    dataset = dataset.append(file_data)
    
end = time.time()
print(dataset.shape)
print(end-start)
dataset.to_csv('merge.dat', sep=' ', header=False, index=False)