# -*- coding: utf-8 -*-
"""
Created on Tue Mar  3 18:18:28 2020

@author: Henke
"""

import math

#Input: dataset=numpy Dataframe, percentage = float between 0 and 1
#Output: X_train,X_test = numpy Dataframe, Y_train,Y_test = numpy Series
def split_test_train(dataset, percentage):
    #Split into X matrix and Y column
    X = dataset[range(0,15)]
    Y = dataset[15]
    #Split into train and test data
    train_rows = int( math.ceil(dataset.shape[0]*percentage) )
    test_rows = int( math.ceil(dataset.shape[0]*(1-percentage)) )
    X_train = X.head(train_rows)
    Y_train = Y.head(train_rows)
    X_test = X.tail(test_rows)
    Y_test = Y.tail(test_rows)
    return X_train, Y_train, X_test, Y_test