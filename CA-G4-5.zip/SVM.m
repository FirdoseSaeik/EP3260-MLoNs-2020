function [x]=SVM(workers_x, workers_y, A, z, u, worker_num, lambda, rho)
%UNTITLED2 �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
[M,~]=size(A);
[L,N]=size(workers_x);
cvx_begin quiet
% cvx_begin
    variable x_var(1,L)
    fxi=sum( pos( 1-workers_y.*(x_var*workers_x) ) )/N + lambda*norm(x_var(1:L-1),2); % this is the SVM loss
    fx_dual=cvx(0);
    fx_augm=cvx(0);
    for i=1:M
        u_reshape=reshape( u(worker_num,i,:), 1, L);
        z_reshape=reshape(z(worker_num,i,:), 1, L);
        fx_dual=fx_dual+A(worker_num,i)*u_reshape*(x_var-z_reshape)';
%         fx_dual=fx_dual+A(worker_num,i)*u(worker_num,i,:)*(x_var-z(worker_num,i,:))';
        fx_augm=fx_augm+rho/2*A(worker_num,i)*norm( (x_var-z_reshape),2 );
    end    
    minimize fxi+fx_dual+fx_augm;
cvx_end
x= x_var;
end

