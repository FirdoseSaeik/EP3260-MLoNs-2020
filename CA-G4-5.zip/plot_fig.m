%% 
clear
close all
clc
%% load
load('total_loss_1')
load('total_loss_2')
load('total_loss_3')
load('total_loss_4')
load('total_loss_5')
load('total_loss_6')

load('total_loss_re_1')
load('total_loss_re_2')
load('total_loss_re_3')
load('total_loss_re_4')
load('total_loss_re_5')
load('total_loss_re_6')

lambda=[10^-3 10^-2 10^-1 1 10 100];

dif_total_loss_1=total_loss_re_1-total_loss_1;
dif_total_loss_2=total_loss_re_2-total_loss_2;
dif_total_loss_3=total_loss_re_3-total_loss_3;
dif_total_loss_4=total_loss_re_4-total_loss_4;
dif_total_loss_5=total_loss_re_5-total_loss_5;
dif_total_loss_6=total_loss_re_6-total_loss_6;

x=1:30;
% x=x*18;
x=x*54;
%% plot
%% with regulizer 
figure (1)
plot(x(2:end),total_loss_re_4(2:end),'r-','markersize', 6.5, 'linewidth', 1.5)
legend('ADMM')
xlabel('Number of signaling exchange T')
ylabel('Total loss')
% axis([-inf, inf, 3 ,7])

figure (2)
plot(x,total_loss_re_4,'r-','markersize', 6.5, 'linewidth', 1.5)
legend('ADMM')
xlabel('Number of signaling exchange T')
ylabel('Total loss')
axis([-inf, inf, 3 ,7])
%% with regulizer 
figure (3)
plot(x(2:end),total_loss_re_2(2:end),'ko--',...
     x(2:end),total_loss_re_4(2:end),'r*-',x(2:end),total_loss_re_5(2:end),'bs-.','markersize', 6.5, 'linewidth', 1.5)
legend('\lambda=10^{-1}','\lambda=1','\lambda=10^1')
xlabel('Number of signaling exchange T')
ylabel('Total loss')
axis([-inf, inf, 3 ,7])
% xticks([x])
grid on

figure (4)
plot(x,total_loss_re_2,'ko--',...
     x,total_loss_re_4,'r*-',x,total_loss_re_5,'bs-.','markersize', 6.5, 'linewidth', 1.5)
legend('\lambda=10^{-1}','\lambda=1','\lambda=10^1')
xlabel('Number of signaling exchange T')
ylabel('Total loss')
axis([-inf, inf, 3 ,7])
% xticks([x])
grid on

%{
%% with regulizer all
figure (1)
plot(x,total_loss_re_4,'kd--',x,total_loss_re_3,'ro-',x,total_loss_re_2,'bx-.',x,total_loss_re_1,'ms--',...
     x,total_loss_re_5,'g>-',x,total_loss_re_6,'ko--','markersize', 6.5, 'linewidth', 1.5)
legend('10^{-3}','10^{-2}','10^{-1}','1','10^1','10^2')
xlabel('Signal exchange T')
ylabel('Total loss')
grid on
hold on;

%% without regulizer
figure (2)
plot(x,total_loss_4,'kd--',x,total_loss_3,'ro-',x,total_loss_2,'bx-.',x,total_loss_1,'ms--',...
     x,total_loss_5,'g>-',x,total_loss_6,'ko--','markersize', 6.5, 'linewidth', 1.5)
legend('10^{-3}','10^{-2}','10^{-1}','1','10^1','10^2')
xlabel('Signal exchange T')
ylabel('Total loss')
grid on
hold on;

%% without regulizer
figure (3)
plot(x,dif_total_loss_4,'kd--',x,dif_total_loss_3,'ro-',x,dif_total_loss_2,'bx-.',x,dif_total_loss_1,'ms--',...
     x,dif_total_loss_5,'g>-',x,dif_total_loss_6,'ko--','markersize', 6.5, 'linewidth', 1.5)
legend('10^{-3}','10^{-2}','10^{-1}','1','10^1','10^2')
xlabel('Signal exchange T')
ylabel('Total loss')
grid on
hold on;
%}