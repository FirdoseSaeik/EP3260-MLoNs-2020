%% 
clear
close all
clc
tic
%% 
load('workers_x')
load('workers_y')
load('A')
%% for test
% workers_x=workers_x(:,:,1:10);
% workers_y=workers_y(:,1:10);
%%
[M,L,N]=size(workers_x); % M: agent number; L: feature+1; N: training size
for i=1:M
    A(i,i)=0;
end
%%
A=double(A);
%% change workers_x last element to 1 so that we have wx-b
workers_x(:,L,:)=1;
%% change it to binary '0' 
workers_y_bin=ones(1,M*N);
Pos=find(workers_y);
workers_y_bin(Pos)=-1;
workers_y_bin=reshape(workers_y_bin,M,N);
lambda=10^-1; %lambda is the hyperparameter 
rho=1.5;

%% ADMM solver
x = zeros(M,L);
z = zeros(M,M,L);
u_k = zeros(M,M,L);
u_k1=zeros(M,M,L);
iter_max=30;
total_loss=zeros(1,iter_max);
count=0;
while (count<iter_max)
    count
    %% update x    
    for i=1:M
        workers_x_1=workers_x(i,:,:);
        workers_x_1_proc=reshape(workers_x_1,L,N);
        [x(i,:)]=SVM(workers_x_1_proc,workers_y_bin(i,:),A,z,u_k, i, lambda, rho);    
    end
    %% update z
    for i=1:M
        for j=1:M
            if A(i,j)
                z(i,j,:)=1/2*( x(i,:)+ x(j,:)+ reshape( 1/rho*(u_k(i,j,:)+ u_k(j,i,:)), 1, L) );
            end
        end
    end
    %% update u
    for i=1:M
        for j=1:M
            if A(i,j)
%                 u_k1(i,j,:)=u_k(i,j,:) - rho*(reshape(x(i,:),1,1,L)-z(i,j,:));
                u_k1(i,j,:)=u_k(i,j,:)+rho*(reshape(x(i,:),1,1,L)-z(i,j,:));
%                 z(i,j,:)=1/2*( x(i,:)+ x(j,:)+ reshape( 1/rho*(u_k(i,j,:)+ u_k(j,i,:)), 1, L) );
            end
%             u_k1(i,j,:)=u_k(i,j,:)+rho*(reshape(x(i,:),1,1,L)-z(i,j,:));
        end
    end
    u_k=u_k1;
    %% update count
    count=count+1;
    %% total loss    
    for i=1:M
        workers_x_1=workers_x(i,:,:);
        workers_x_1_proc=reshape(workers_x_1,L,N);
        total_loss(count)=total_loss(count)+ sum( max( 1-workers_y_bin(i,:).*(x(i,:)*workers_x_1_proc),0 ) )/N + lambda*sum( x(i,1:end-1).^2);
    end
end
plot(total_loss)
toc
total_loss_01=total_loss;
save total_loss_01 total_loss_01

%{
%% reshape example
workers_x_1=workers_x(1,:,:);
workers_x_1_proc=reshape(workers_x_1,L,N);

for i=1:L
    for j=1:N
        if workers_x_1(1,i,j)==workers_x_1_proc(i,j)
            continue
        else
            disp('fasle')
        end
    end
end
Pos=find(workers_x_1(1,:,:));
Pos2=find(workers_x_1_proc);
%}
















